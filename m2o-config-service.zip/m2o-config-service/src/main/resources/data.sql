--
INSERT INTO config (domain, _key, value)
    VALUES ('domain','key','{"value":"foo"}');