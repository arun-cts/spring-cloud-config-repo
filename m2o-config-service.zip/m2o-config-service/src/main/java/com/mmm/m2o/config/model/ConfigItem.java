package com.mmm.m2o.config.model;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.Size;

import static javax.persistence.GenerationType.IDENTITY;

@Data
@Entity
@Table(name = "config", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"domain","_key"})
})
public class ConfigItem {
    @Id
    @GeneratedValue(strategy = IDENTITY)
    public Long id;

    @Column(nullable = false) @Size(min = 3, max = 64)
    public String domain;

    @Column(name = "_key", nullable = false) @Size(min = 3, max = 64)
    public String key;

    @Column(nullable = false) @Size(min = 3)
    public String value;   //json
}

/**
 *  (c) 2019+ 3M Inc. All Rights Reserved.
 */