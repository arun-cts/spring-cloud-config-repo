package com.mmm.m2o.config.repo;

import com.mmm.m2o.config.model.ConfigItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ConfigRepo extends JpaRepository<ConfigItem, Long> {

    @Query("FROM ConfigItem WHERE domain=:domain AND key=:key")
    ConfigItem findByDomainAndKey(@Param("domain") String domain, @Param("key") String key);
}

/**
 *  (c) 2019+ 3M Inc. All Rights Reserved.
 */