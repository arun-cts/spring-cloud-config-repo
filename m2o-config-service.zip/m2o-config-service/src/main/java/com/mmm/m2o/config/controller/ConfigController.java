package com.mmm.m2o.config.controller;

import com.mmm.m2o.config.model.ConfigItem;
import com.mmm.m2o.config.repo.ConfigRepo;
import com.mmm.m2o.config.service.ConfigService;
import com.mmm.m2o.error.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.net.URISyntaxException;

@RestController
public class ConfigController {

    private static final Logger LOG = LoggerFactory.getLogger(ConfigController.class);

    @Autowired private ConfigRepo configRepo;
    @Autowired private ConfigService configService;

    @GetMapping("/config/{id}")
    public ConfigItem findById(@PathVariable("id") ConfigItem item) {
        return item;
    }

    /**
     *
     * @param domain
     * @param key
     * @return
     */
    @GetMapping("/config/{domain}/{key}")
    public ResponseEntity<ConfigItem> get(@PathVariable String domain,
                                      @PathVariable String key) {
        ConfigItem item = configRepo.findByDomainAndKey(domain,key);
        if (item==null)
            throw new ResourceNotFoundException("config item not found for "+domain+"/"+key);
        return new ResponseEntity<>(item, HttpStatus.OK);
    }

    /**
     *
     * @param configItem
     * @return
     * @throws URISyntaxException
     */
    @PostMapping("/config/{domain}/{key}")
    public ResponseEntity<ConfigItem> create(@RequestBody ConfigItem configItem) throws URISyntaxException {
        ConfigItem createdItem = configService.create(configItem);
        if (createdItem == null) {
            return ResponseEntity.notFound().build();
        } else {
            URI uri = ServletUriComponentsBuilder.fromCurrentRequest()
                    .path("/{id}")
                    .buildAndExpand(createdItem.id)
                    .toUri();

            return ResponseEntity.created(uri).body(createdItem);
        }
    }
}

/**
 *  (c) 2019+ 3M Inc. All Rights Reserved.
 */