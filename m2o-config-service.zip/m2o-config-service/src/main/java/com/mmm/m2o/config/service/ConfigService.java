package com.mmm.m2o.config.service;

import com.mmm.m2o.config.model.ConfigItem;
import com.mmm.m2o.config.repo.ConfigRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConfigService {

    private static final Logger LOG = LoggerFactory.getLogger(ConfigService.class);

    @Autowired private ConfigRepo configRepo;

    public ConfigItem create(ConfigItem configItem) {
        return configItem;
    }
}

/**
 *  (c) 2019+ 3M Inc. All Rights Reserved.
 */