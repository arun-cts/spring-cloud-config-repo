package com.mmm.m2o.config.controller;

import com.mmm.m2o.config.model.ConfigItem;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

public class ConfigControllerTest extends AbstractControllerTest {

    @Override @Before
    public void setUp() { super.setUp(); }

    @Test
    public void givenAnyone_whenGetItem_thenReturnItem() throws Exception {
        String uri = "/config/1";
        MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri)
                .accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(200, status);
        String content = mvcResult.getResponse().getContentAsString();
        ConfigItem item = super.mapFromJson(content, ConfigItem.class);
        assertTrue(item.domain.equals("domain"));
    }

    @Test
    public void givenAnyone_whenGetMissing_thenNotFound() throws Exception {
        String uri = "/config/99999";
        MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri)
                .accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(200, status);
        assertEquals(0,mvcResult.getResponse().getContentLength());
    }

    @Test
    public void givenAnyone_whenGetDomainKey_thenReturnItem() throws Exception {
        String uri = "/config/domain/key";
        MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri)
                .accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(200, status);
        String content = mvcResult.getResponse().getContentAsString();
        ConfigItem item = super.mapFromJson(content, ConfigItem.class);
        assertTrue(item.domain.equals("domain"));
    }
}

/**
 *  (c) 2019+ 3M Inc. All Rights Reserved.
 */