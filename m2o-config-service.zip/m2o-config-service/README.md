# M2O Config

## Developer Notes

Jacoco: https://reflectoring.io/jacoco/

```./gradlew build jacocoTestReport```

## Install & Setup

## Git

## DB setup

### References

1. https://medium.com/@nani2ratna/spring-cloud-config-server-with-jdbc-55de8f7ec86d
